I'm Using it with 10.14.x mojave
Everything works except wifi(you can replace it or use usb wifi module) and you cant configure backlight levels, its always on
